const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const PORT = 3000;

app.use(bodyParser.json());

let clientes = [];

// Rota para adicionar um novo cliente
app.post('/clientes', (req, res) => {
  console.log('Corpo da requisição:', req.body);
  const novoCliente = req.body;
  console.log('Cliente recebido para adição:', novoCliente);

  // Certifique-se de que o ID é único
  const clienteExistente = clientes.find(cliente => cliente.idCliente === novoCliente.idCliente);
  if (clienteExistente) {
    return res.status(400).json({ message: 'ID do cliente já existe. Escolha um ID único.' });
  }

  clientes.push(novoCliente);

  // Log para verificar se o cliente foi adicionado corretamente
  console.log('Clientes após adição:', clientes);

  return res.status(201).json({ message: 'Cliente adicionado com sucesso', clientes });
});


// Obter todos os clientes ou um cliente específico por ID
app.get('/clientes/:id?', (req, res) => {
  const clienteId = req.params.id;

  if (clienteId) {
    // Se um ID for fornecido, procure o cliente por ID
    const cliente = clientes.find((c) => c.idCliente == clienteId);

    if (cliente) {
      res.json(cliente);
    } else {
      res.status(404).json({ message: 'Cliente não encontrado' });
    }
  } else {
    // Se nenhum ID for fornecido, retorne todos os clientes
    res.json(clientes);
  }
});

app.put('/clientes/:id', (req, res) => {
  const clienteId = req.params.id;
  const clienteIndex = clientes.findIndex((c) => c.idCliente === parseInt(clienteId));

  if (clienteIndex !== -1) {
    clientes[clienteIndex] = req.body;
    res.json({ message: 'Cliente alterado com sucesso', cliente: clientes[clienteIndex] });
  } else {
    res.status(404).json({ message: 'Cliente não encontrado' });
  }
});

app.delete('/clientes/:id', (req, res) => {
  const clienteId = req.params.id;
  clientes = clientes.filter((c) => c.idCliente !== parseInt(clienteId));
  res.json({ message: 'Cliente excluído com sucesso' });
});

app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
